﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOKMS
{
    public partial class User1 : Form
    {
        public User1()
        {
            InitializeComponent();
        }

        private void 当前借出图书和ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user3 user3 = new user3();
            user3.ShowDialog();
        }

        private void 图书查看和借阅ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user2 user2 = new user2();
            user2.ShowDialog();
        }
    }
}
