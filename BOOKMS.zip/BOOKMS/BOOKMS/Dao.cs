﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace BookMs
{
    //用于数据库连接
    internal class Dao
    {
        SqlConnection sc;
        public SqlConnection connect()
        {
            //数据库连接操作 返回一个连接
            string str = @"Data Source=LEONARDO-DICAPR;Initial Catalog=BookDB;Integrated Security=True";
            sc = new SqlConnection(str);//创建数据库连接对象
            sc.Open();//打开数据库
            return sc;//返回数据库连接对象
        }

        public SqlCommand command(string sql)
        {
            //创建sql命令
            SqlCommand cmd = new SqlCommand(sql, connect());
            return cmd;
        }
        public int Execute(string sql)
        {
            //更新操作(update delete insert)
            return command(sql).ExecuteNonQuery();
        }

        public SqlDataReader reader(string sql)
        {
            //读取操作(select)
            return command(sql).ExecuteReader();
        }
        public void DaoClose()
        {
            sc.Close();
        }
    }
}
