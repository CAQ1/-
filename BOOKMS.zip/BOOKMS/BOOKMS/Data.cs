﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKMS
{
    internal class Data
    {
        public static string UID = "", UName = "";//用户登录用的Id和名称
    }
}
