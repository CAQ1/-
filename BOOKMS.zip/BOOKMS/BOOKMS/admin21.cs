﻿using BookMs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOKMS
{
    public partial class admin21 : Form
    {
        public admin21()
        {
            InitializeComponent();
        }

        private void admin21_Load(object sender, EventArgs e)
        {

        }
        private bool isEmpty()
        {
            foreach (Control control in this.Controls)
            {
                if (control is TextBox)
                {
                    if (control.Text == string.Empty)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //判断文本是否为空
            if (isEmpty())
            {
                Dao dao = new Dao();
                string sql = $"insert into T_BOOK values('{textBox1.Text}','{textBox2.Text}','{textBox3.Text}','{textBox4.Text}',{textBox5.Text})";
                int n = dao.Execute(sql);
                if (n > 0)
                {
                    MessageBox.Show("添加成功");
                    foreach (Control control in this.Controls)
                    {
                        //循环遍历所有组件
                        if (control is TextBox)
                        {
                            //判断这个组件是不是TextBox,是的话就清空
                            control.Text = string.Empty; // 清空文本框
                        }
                    }
                }
                else
                {
                    MessageBox.Show("添加失败");
                }
            }
            else
            {
                MessageBox.Show("信息不全，请仔细检查");
            }
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                //循环遍历所有组件
                if (control is TextBox)
                {
                    //判断这个组件是不是TextBox,是的话就清空
                    control.Text = string.Empty; // 清空文本框
                }
            }
        }
    }
}
